# buffalo_geoforming
This is a vide game about the geopolitics of geoforming to fight global warming
