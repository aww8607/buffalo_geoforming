code_name[0] = "(O)il Drillers";
code_name[1] = "(S)abatage";
code_name[2] = "";
code_name[3] = "";
code_name[4] = "";
code_name[5] = "";
code_name[6] = "";
code_name[7] = "";
code_name[8] = "";
code_name[9] = "";
code_name[10] = "";
code_name[11] = "";
code_name[12] = "";



code_letter[0] = "O";
code_letter[1] = "S";
code_letter[2] = "";
code_letter[3] = "";
code_letter[4] = "";
code_letter[5] = "";
code_letter[6] = "";
code_letter[7] = "";
code_letter[8] = "";
code_letter[9] = "";
code_letter[10] = "";
code_letter[11] = "";
code_letter[12] = "";


map_box_names[0] = "Political Party";
map_box_names[1] = "Energy";
map_box_names[2] = "Technology";
map_box_names[3] = "Agriculture";
map_box_names[4] = "Local Government";
map_box_names[5] = "Transportation";


map_box_modifier[0] = "a ";
map_box_modifier[1] = "an";
map_box_modifier[2] = "a";
map_box_modifier[3] = "an";
map_box_modifier[4] = "a";
map_box_modifier[5] = "a";