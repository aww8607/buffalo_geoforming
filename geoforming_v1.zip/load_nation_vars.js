resource_1[0]=0;
resource_1[1]=2;
resource_1[2]=4;
resource_1[3]=1;
resource_1[4]=3;
resource_1[5]=0;
resource_1[6]=2;
resource_1[7]=4;

resource_2[0]=1;
resource_2[1]=3;
resource_2[2]=0;
resource_2[3]=2;
resource_2[4]=4;
resource_2[5]=1;
resource_2[6]=3;
resource_2[7]=0;

carbon_start_level[0]=1;
carbon_start_level[1]=3;
carbon_start_level[2]=3;
carbon_start_level[3]=3;
carbon_start_level[4]=2;
carbon_start_level[5]=2;
carbon_start_level[6]=1;
carbon_start_level[7]=1;

control_level[0]=0;
control_level[1]=0;
control_level[2]=0;
control_level[3]=0;
control_level[4]=0;
control_level[5]=0;
control_level[6]=0;
control_level[7]=0;

control_threshold[0]=4;
control_threshold[1]=4;
control_threshold[2]=4;
control_threshold[3]=4;
control_threshold[4]=4;
control_threshold[5]=4;
control_threshold[6]=4;
control_threshold[7]=4;

//End