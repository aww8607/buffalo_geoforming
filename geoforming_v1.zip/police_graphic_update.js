function police_graphic_update(stage_check)
{
	/*
	
	for(var n = 0; n < 56; n++)
	{
		map_big_police_array[n].visible = false;
		map_small_police_array[n].visible = false;
		map_small_yellow_police[n].visible = false;
		red_police_array[n]=0;
		yellow_police_array[n]=0;
	
	}
	
	if(stage_check==1)
	{
		for(var k = 0; k < 56; k++)
		{
			if(yellow_police_choice>-1)	
			{	
				if(map_colors_array[k]==yellow_police_choice)
				{
					yellow_police_array[k] = 1;
				}
			}
			
			if(red_police_choice > -1)
			{
				if(k == red_police_choice )
				{
					red_police_array[k] = 2;	
				}
				else if(k+7 == red_police_choice && k>=0)
				{
					red_police_array[k] = 1;
				}
				else if(k-7 == red_police_choice && k<56)
				{
					red_police_array[k] = 1;
				}
				else if(k-1 == red_police_choice && k%7 != 0)
				{
					red_police_array[k] = 1;
				}
				else if(k+1 == red_police_choice && k%7 != 6)
				{
					red_police_array[k] = 1;
				}
				else if(k+6 == red_police_choice && k%7 != 0 && k >= 0)
				{
					red_police_array[k] = 1;
				}
				else if(k-8 == red_police_choice && k%7 != 0 && k <56)
				{
					red_police_array[k] = 1;
				}
				else if(k+8 == red_police_choice && k%7 != 6 && k >= 0)
				{
					red_police_array[k] = 1;
				}
				else if(k-6 == red_police_choice && k%7 != 6 && k <56)
				{
					red_police_array[k] = 1;
				}
			}	
			
			
			
			
			
		}
		
		for(var g=0; g<56; g++)
		{
			if(red_police_array[g] == 2)
			{
				map_big_police_array[g].visible = true;
			}
			else if(red_police_array[g] == 1)
			{
				map_small_police_array[g].visible = true;	
			}
			else if(yellow_police_array[g] == 1)
			{
				map_small_yellow_police[g].visible = true;	
			}
			
			
		}
	}	
	
	*/

}